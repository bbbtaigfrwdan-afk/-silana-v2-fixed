console.log('🐾 Starting...');

import { Worker } from 'worker_threads';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { watchFile, unwatchFile } from 'fs';
import readline from 'readline';

const __dirname = dirname(fileURLToPath(import.meta.url));
const rl = readline.createInterface(process.stdin, process.stdout);

const MAIN_FILE = 'main.js';
const BASE_DELAY = 5 * 1000; // first retry after 5s
const MAX_DELAY = 2 * 60 * 1000; // never wait more than 2 minutes
const STABLE_AFTER = 2 * 60 * 1000; // a run longer than this resets the backoff

let worker = null;
let generation = 0; // identifies the current worker, so exit events of old ones are ignored
let restartTimer = null;
let failures = 0;
let startedAt = 0;

function start(file = MAIN_FILE) {
	if (worker) return;
	const full = join(__dirname, file);
	const gen = ++generation;
	startedAt = Date.now();

	const w = new Worker(full);
	worker = w;

	w.on('message', (msg) => {
		if (gen !== generation) return;
		console.log('[MESSAGE]', msg);
		if (msg === 'restart' || msg === 'reset') scheduleRestart('requested by the bot');
	});

	// Without this listener an error inside the worker (for example a missing
	// better-sqlite3 binding) crashes the whole process and the panel stops the server.
	w.on('error', (err) => {
		if (gen !== generation) return;
		console.error('❌ Worker error:', err?.stack || err);
		const text = String(err?.message || err);
		if (/better_sqlite3|bindings file/i.test(text)) {
			console.error('💡 better-sqlite3 is not built for this Node version. Run: npm rebuild better-sqlite3  (or delete node_modules and run npm install)');
		}
	});

	w.on('exit', (code) => {
		if (gen !== generation) return; // an old worker that we already replaced
		worker = null;
		console.log('❗ Worker exited with code', code);
		if (code !== 0) scheduleRestart(`worker exited with code ${code}`);
		watchFile(full, () => {
			unwatchFile(full);
			console.log('♻️ File updated → Restarting...');
			scheduleRestart('file updated', true);
		});
	});

	if (!rl.listenerCount('line')) {
		rl.on('line', (line) => {
			const cmd = line.trim().toLowerCase();
			if (!cmd) return;

			if (cmd === 'exit') {
				console.log('⛔ Exiting...');
				worker?.terminate();
				process.exit(0);
			}
			if (cmd === 'restart' || cmd === 'reset') {
				console.log('🍃Restart...');
				scheduleRestart('console command', true);
				return;
			}

			worker?.postMessage(cmd);
		});
	}
}

async function stop() {
	if (!worker) return;
	const w = worker;
	worker = null;
	generation++; // from now on events of this worker are ignored
	try {
		await w.terminate();
	} catch {}
}

function scheduleRestart(reason, immediate = false) {
	if (restartTimer) return; // a restart is already waiting

	if (!immediate) {
		if (Date.now() - startedAt > STABLE_AFTER) failures = 0;
		else failures++;
	}

	const delay = immediate ? 0 : Math.min(BASE_DELAY * 2 ** Math.max(failures - 1, 0), MAX_DELAY);
	if (delay) console.log(`⏳ Restarting in ${Math.round(delay / 1000)}s (${reason})`);

	restartTimer = setTimeout(async () => {
		restartTimer = null;
		await stop();
		start(MAIN_FILE);
	}, delay);
}

process.on('uncaughtException', (e) => console.error('uncaughtException:', e));
process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e));

start(MAIN_FILE);
